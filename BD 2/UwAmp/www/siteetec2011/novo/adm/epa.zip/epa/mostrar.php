<?php
$pagina = $_GET['np'];
require_once '../class/Oficina.php';
$o = new Oficina();
echo '<table><tr><td><h3>EPA _ ETEC</h3></td></tr></table>';
$o->mostrar($pagina,"adm");
?>