<?php 
include "../conexao/conn.php";

$codTurma = $_GET['codturma'];
$codDisciplina = $_GET['coddisciplina'];

// pegar a etapa atual;
$rsEtapaAtual = mysql_query("SELECT * FROM Etapas WHERE atual=1");
$codEtapa = mysql_result($rsEtapaAtual, 0);

?>

<script type="text/javascript">
	$(function(){

		$("#campo_data").keypress(function(evento){
			
			if ((event.which < 48 || event.which > 57) && event.which != 190){
				return false;
			}else {
				if (this.value.length == 2) {
					this.value = this.value + '/';
				} else if (this.value.length == 5) {
					this.value = this.value + '/';
				}
			return true;
			}
	
		});

		$(".apagarava").click(function(){
			var codavaliacao = $(this).attr("id");
			$.messager.confirm('Apagar Avaliação','Se apagar a avaliação selecionada as notas digitadas para essa avaliação serão perdidas. Deseja continuar?',function(r){  
			    if (r){  
			        
					$.post("apagar_avaliacao.php", {codAvaliacao: codavaliacao})
					.success(function(){

						$("#main_avaliacoes").load("form_avaliacoes.php?codturma=<?php echo $codTurma ?>&coddisciplina=<?php echo $codDisciplina ?>"); 
						$("#main_notas").load("form_notas.php?codturma=<?php echo $codTurma ?>&coddisciplina=<?php echo $codDisciplina ?>"); 
					})
					.error(function(){
						$.messager.alert('Erro','Erro ao apagar avaliação');  
					}); 
			    }  
			});  
		});
		
		$(".gravarava").click(function(){

			$.post("gravar_avaliacao.php", $("#favaliacao").serialize())
				.success(function(){

				$("#main_avaliacoes").load("form_avaliacoes.php?codturma=<?php echo $codTurma ?>&coddisciplina=<?php echo $codDisciplina ?>"); 
				$("#main_notas").load("form_notas.php?codturma=<?php echo $codTurma ?>&coddisciplina=<?php echo $codDisciplina ?>"); 
			})
			.error(function(){
				$.messager.alert('Erro','Erro ao gravar avaliação');  
			}); 
			    
		});

	});
</script>



<style type="text/css">
#avaliacoes td, #avaliacoes th{
	font-size:7.5pt;
}

</style>

<form id="favaliacao">
<input type=hidden name=codDisciplina value=<?php echo $codDisciplina?> />
<input type=hidden name=codTurma value=<?php echo $codTurma?> />
<table id="avaliacoes" class="ui-widget ui-widget-content">
<thead>
  <tr class="ui-widget-header ">
    <th>Sigla</th>
    <th>Descrição</th>
    <th>Tipo</th>    
    <th>Data</th>    
    <th>Apagar</th>    
  </tr>
 </thead>
 <tbody>

<?php 
$sqlAvaliacoes = "SELECT * FROM Avaliacoes ".
				"WHERE codTurma=$codTurma ".
				"AND codDisciplina=$codDisciplina ".
				"ORDER BY codAvaliacao";
$rsAvaliacoes = mysql_query($sqlAvaliacoes);

if (mysql_num_rows($rsAvaliacoes)<1){
	echo "<td colspan=4>Nenhuma avaliação cadastrada</td>";
}else{
	while ($rowAvaliacoes = mysql_fetch_array($rsAvaliacoes)){
		$codAvaliacao = $rowAvaliacoes['codAvaliacao'];
		echo "<tr>";
		echo "<td>".$rowAvaliacoes['sigla']."</td>";
		echo "<td>".$rowAvaliacoes['descricao']."</td>";
		echo "<td>".$rowAvaliacoes['tipo']."</td>";
		echo "<td>".$rowAvaliacoes['data']."</td>";
		echo "<td><a href='#' class='ui-icon ui-icon-trash apagarava' id=$codAvaliacao></a></td>";
		echo "</tr>";
	}
}
?>  	

  	<tr>
  		<td><input type=text name=sigla size=4 maxlength="4"></td>
  		<td><input type=text name=descricao></td>
  		<td><select name=tipo id='tipo'>
  			<option>Conhecimentos</option>
  			<option>Habilidades</option>
  			<option>Atitudes</option>
  		</select></td>
  		<td><input id='campo_data' type=text name='data' size=10 maxlength=10></td>
  		<td><a href='#' class='ui-icon ui-icon-check gravarava'></a></td>
  	</tr>
  	</tbody>
</table>
</form>


