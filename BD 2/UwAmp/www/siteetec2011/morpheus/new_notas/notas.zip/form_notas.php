<?php 
 
include "../conexao/conn.php";

$codTurma = $_GET['codturma'];
$codDisciplina = $_GET['coddisciplina'];

// pegar a etapa atual;
$rsEtapaAtual = mysql_query("SELECT * FROM Etapas WHERE atual=1");
$codEtapa = mysql_result($rsEtapaAtual, 0);

 ?>

<script type="text/javascript">
	$(function(){
		$(".lock").toggleClass("ui-icon-unlocked");

		$("#btn_gravar").click(function(){
			alert("salvar");
			return false;
		});

		$(".campo_mencaoI").change(function () {
			var codaluno = $(this).attr("codaluno");
			var mencao = $(this).find("option:selected").text();
			$.post("gravar_mencao_intermediaria.php", 
				{codaluno: codaluno, coddisciplina: <?php echo $codDisciplina ?>, mencao: mencao})
	        .error(function() { alert("Erro ao gravar nota. Banco de Dados Indisponível"); }) 
        });

		$(".campo_mencaoF").change(function () {
			var codaluno = $(this).attr("codaluno");
			var mencao = $(this).find("option:selected").text();
			$.post("gravar_mencao_final.php", 
				{codaluno: codaluno, coddisciplina: <?php echo $codDisciplina ?>, mencao: mencao})
	        .error(function() { alert("Erro ao gravar nota. Banco de Dados Indisponível"); }) 
        });

		$(".campo_mencao_avaliacao").change(function () {
			var codaluno = $(this).attr("codaluno");
			var codavaliacao = $(this).attr("codavaliacao");
	        var mencao = $(this).find("option:selected").text();
	        $.post("gravar_mencaoavaliacao.php", {codaluno: codaluno, codavaliacao: codavaliacao, mencao: mencao})
	        .error(function() { alert("Erro ao gravar nota. Banco de Dados Indisponível"); })	        
        });

		//botao que trava e habilita digitacao de nota
		$(".lock").click(function(){
        	$(this).toggleClass("ui-icon-unlocked");
        	var codavaliacao = "."+ $(this).attr("id");
        	if ($(codavaliacao).attr("disabled") == "disabled"){
        		$(codavaliacao).removeAttr("disabled");
        	}else{
        		$(codavaliacao).attr("disabled", "disabled");
        	}
        	
        });
	});

</script>

<?php

$sqlAlunos = "SELECT Matriculas.*, Alunos.nomeAluno, Alunos.codAluno FROM Matriculas ".
			"INNER JOIN Alunos ON Alunos.codAluno=Matriculas.codAluno ".
			"WHERE Matriculas.codTurma=$codTurma ".
			"ORDER BY nomeAluno";
$rsAlunos = mysql_query($sqlAlunos);

$sqlAvaliacoes = "SELECT * FROM Avaliacoes ".
				"WHERE codTurma=$codTurma AND codDisciplina=$codDisciplina";
$rsAvaliacoes = mysql_query($sqlAvaliacoes);

if (mysql_num_rows($rsAlunos)<1){
	
	?>
	<div class="ui-widget">
		<div class="ui-state-error ui-corner-all" style="padding: 0 .7em;"> 
			<p><span class="ui-icon ui-icon-alert" style="float: left; margin-right: .3em;"></span> 
			<strong>Erro: </strong>Nenhum aluno cadastrado na turma. Procure a secretaria.</p>
		</div>
	</div>
	<?php
	
}else{
	if (mysql_num_rows($rsAvaliacoes)<2) {
?>
			<div class="ui-widget">
				<div class="ui-state-highlight ui-corner-all" style="padding: 0 .7em;"> 
					<p><span class="ui-icon ui-icon-info" style="float: left; margin-right: .3em;"></span> 
					<strong>Atenção:</strong> Cadastre pelo menos duas avaliações antes de digitar as menções</p>
				</div>
			</div>
	<?php 
	}
	?>
	<form id='fnotas' method='post'>
		<input type=hidden name=codTurma value=<?php echo $codTurma?> />
		<input type=hidden name=codDisciplina value=<?php echo $codDisciplina?> />
		<table class='ui-widget ui-widget-content'>
		<thead>
			<tr class='ui-widget-header '>
				<th>Nome</th>
				<?php
				while ($rowAvaliacoes = mysql_fetch_array($rsAvaliacoes)){
					$codAvaliacao = $rowAvaliacoes['codAvaliacao'];
					$sigla = $rowAvaliacoes["sigla"];
					?>
					<th><?php echo $sigla ?>
					<a href='#' class="ui-icon ui-icon-locked lock" id=<?php echo $codAvaliacao ?>></a>
					</th>
				<?php
				}
				?>
				<th>MI</th>
				<th alt='Mencao Final'>MF</th>
			</tr>
		</thead>
		<tbody>
			<?php
			while($rowAluno = mysql_fetch_array($rsAlunos)){
				$mencaoI="";
				$mencaoF="";
				//executar novamente para posicionar o cursor no ínicio
				$rsAvaliacoes = mysql_query($sqlAvaliacoes);
				$qtdeAvaliacoes = mysql_num_rows($rsAvaliacoes) + 2; //para considerar MI e MF
				$codAluno = $rowAluno["codAluno"];
				echo "<tr><td>".$rowAluno["nomeAluno"]."</td>";
				if ($rowAluno["status"]!="MA"){ //Se não for matrícula ativa desabilita a linha
					?>
					<td colspan=<?php echo $qtdeAvaliacoes?> style='background-color:#999999'>
						<?php echo $rowAluno["status"]?>
					</td>
					<?php
				}else{
					while ($rowAvaliacoes = mysql_fetch_array($rsAvaliacoes)){
					$codAvaliacao = $rowAvaliacoes['codAvaliacao'];
					
					//buscar as notas das avaliacoes do aluno
					$sqlMencoesAvaliacoes = "SELECT mencao FROM MencoesAvaliacoes ".
											"WHERE codAluno=$codAluno ".
											"AND codAvaliacao=$codAvaliacao";
					$rsMencoesAvaliacoes = mysql_query($sqlMencoesAvaliacoes);
					
					//verifica se o aluno tem nota na avaliação
					if (mysql_num_rows($rsMencoesAvaliacoes)<1) 
						$mencao="NULL"; 
					else 
						$mencao = mysql_result($rsMencoesAvaliacoes, 0, "mencao");
					?>
					
					<!-- cria o select com a nota selecionada -->
					<td>
						<select 
						  class="campo_mencao_avaliacao <?php echo $codAvaliacao?>"
						  name=<?php echo $codAluno."_".$codAvaliacao?> 
						  codaluno=<?php echo $codAluno?> 
						  codavaliacao=<?php echo $codAvaliacao?>
						   >
							<?php
							if ($mencao=="NULL") echo "<option value='NULL'> </option>";
							if ($mencao=="MB") echo "<option selected=selected >MB</option>"; 
								else echo "<option>MB</option>"; 
							if ($mencao=="B") echo "<option selected=selected >B</option>"; 
								else echo "<option>B</option>"; 
							if ($mencao=="R") echo "<option selected=selected >R</option>"; 
								else echo "<option>R</option>"; 
							if ($mencao=="I") echo "<option selected=selected >I</option>"; 
								else echo "<option>I</option>"; 
							?>
						</select>
					</td>

					<?php
					}// fim do while das avaliacoes

					//mencao final ou intermediaria dependendo de qual foi habilitada na tabela Etapas
					$sqlMencoes = "SELECT * FROM Mencoes ".
									"WHERE codAluno=$codAluno ".
									"AND codDisciplina=$codDisciplina ".
									"AND codEtapa=$codEtapa";
					$rsMencoes = mysql_query($sqlMencoes);

					if (mysql_num_rows($rsMencoes)>0){
						$mencaoI = mysql_result($rsMencoes, 0, "mencaoIntermediaria");
						$mencaoF = mysql_result($rsMencoes, 0, "mencaoFinal");
					}
					
					//campo menção intermediaria habilitado
					if (mysql_result($rsEtapaAtual, 0, "habilitaIntermediaria")==1){
					?>
					<td>
						<select 
						  class="campo_mencaoI"
						  name=<?php echo "I".$codAluno?> 
						  codaluno=<?php echo $codAluno?> 
						>
					<?php
		
						if ($mencaoI=="") echo "<option selected=selected value='NULL'> </option>"; 
							else echo "<option value='NULL'> </option>";
						if ($mencaoI=="MB") echo "<option selected=selected >MB</option>"; 
							else echo "<option>MB</option>"; 
						if ($mencaoI=="B") echo "<option selected=selected >B</option>"; 
							else echo "<option>B</option>"; 
						if ($mencaoI=="R") echo "<option selected=selected >R</option>"; 
							else echo "<option>R</option>"; 
						if ($mencaoI=="I") echo "<option selected=selected >I</option>"; 
							else echo "<option>I</option>"; 
						echo "</select></td>";
						echo "<td>$mencaoF</td>";
					}elseif (mysql_result($rsEtapaAtual, 0, "habilitaFinal")==1){

					//campo mencao final habilitado
						echo "<td>$mencaoI</td>";
					?>
					<td>
						<select 
						  class="campo_mencaoF"
						  name=<?php echo "F".$codAluno?> 
						  codaluno=<?php echo $codAluno?> 
						>
						<?php	
						if ($mencaoF=="") echo "<option selected=selected value='NULL'> </option>"; 
							else echo "<option value='NULL'> </option>";
						if ($mencaoF=="MB") echo "<option selected=selected >MB</option>"; 
							else echo "<option>MB</option>"; 
						if ($mencaoF=="B") echo "<option selected=selected >B</option>"; 
							else echo "<option>B</option>"; 
						if ($mencaoF=="R") echo "<option selected=selected >R</option>"; 
							else echo "<option>R</option>"; 
						if ($mencaoF=="I") echo "<option selected=selected >I</option>"; 
							else echo "<option>I</option>"; 
						echo "</select></td>";
					}else{
						//nenhum campo habilitado
						echo "<td>$mencaoI</td>";
						echo "<td>$mencaoF</td>";
					}
				echo "</tr>";
				}//fim do if que verifica se o aluno tem matricula ativa
			}//fim do loop que percorre a lista de alunos
		}
			?>

		</tbody>
		</table>

		<?php	
			//só permite impressão para cadastrou ao menos duas avaliacoes
			/* *** DESABILITAR ENQUANTO NÃO RESOLVER O RELATÓRIO DE NOTAS
			if (mysql_num_rows($rsAvaliacoes)>=2) {
				echo "<a href=# id='btn_imprimir'>Imprimir</a>";
			}
			*/
		?>
	</form>