<?php

include "../conexao/conn.php";

$codAluno = $_POST["codaluno"];
$codDisciplina = $_POST["coddisciplina"];
$mencao = $_POST["mencao"];

// pegar a etapa atual;
$rsEtapaAtual = mysql_query("SELECT * FROM Etapas WHERE atual=1");
$codEtapa = mysql_result($rsEtapaAtual, 0);

$sql = "INSERT mencoes (codAluno, codDisciplina, codEtapa, mencaoIntermediaria) ".
		"VALUES ($codAluno, $codDisciplina, $codEtapa, '$mencao') ".
		"ON DUPLICATE KEY UPDATE mencaoIntermediaria='$mencao'";

$rs = mysql_query($sql);

?>