	<script type="text/javascript" src="../jquery/js/jquery-ui-1.8.16.custom.min.js"></script>
    <script type="text/javascript" src="../jquery/jquery-1.6.min.js"></script>
	<script type="text/javascript" src="../jquery/jquery.easyui.min.js"></script>	
	<link rel="stylesheet" type="text/css" href="../jquery/themes/default/easyui.css">
	<link rel="stylesheet" type="text/css" href="../jquery/themes/icon.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link type="text/css" href="../jquery/css/cupertino/jquery-ui-1.8.16.custom.css" rel="stylesheet" />	
	

<?php

//verificar se usuário está logado e se tem permissões
session_name('jcLogin');
session_start();

if(!$_SESSION['id']){
	?>
	<div class="ui-widget">
		<div class="ui-state-error ui-corner-all" style="padding: 0 .7em;"> 
			<p><span class="ui-icon ui-icon-alert" style="float: left; margin-right: .3em;"></span> 
			<strong>Acesso Negado: </strong>Você precisa estar logado para acessar essa página.
			<a href="../index.php">Fazer Login</a></p>
		</div>
	</div>
	<?php
	
	exit();
}

include "../conexao/conn.php";

?>

<script type="text/javascript">
	$(function(){

		//tratamento de evento do item Disciplina, só é ativado quando clicado nas disciplina (icone de arquivo)
		$(".tree-file + .tree-title").click(
			function(){

				var disciplina = $(this).html();
				var array_disciplina = disciplina.split("#");
				var cod_disciplina = array_disciplina[2];
				var cod_turma = array_disciplina[3];
				
				//$("#main_notas").html(cod_disciplina + " " + cod_turma);
				$("#main_notas").load("form_notas.php?codturma="+cod_turma+"&coddisciplina="+cod_disciplina);
				$("#main_avaliacoes").load("form_avaliacoes.php?codturma="+cod_turma+"&coddisciplina="+cod_disciplina);
			}
		);

		
	});

</script>

<div class="ui-state-default" style="font-size: 20px;height:30px;width:1100px;margin:0 auto;">
<div id="logo">ETECIA - Men&ccedil;&otilde;es</div>
<div id="link-voltar"><a href="../index.php"><< voltar para etecia.com.br</a></div>
</div>

<div id="principal">
<div class="easyui-layout" style="width:1100px;height:1200;">
        <div region="west" split="true" title="Disciplinas" style="width:200px;">
		   <?php include "get_tree_turmas.php"; ?>
        </div>
        <div region="center" title="Notas" style="background:#fafafa;overflow:hidden">
        	<div id="main_notas"></div>
        </div>
        <div region="east" split="true" title="Avalia&ccedil;&otilde;es" style="width:400px;">
		   <div id="main_avaliacoes"></div>
        </div>
    </div>
<div>
