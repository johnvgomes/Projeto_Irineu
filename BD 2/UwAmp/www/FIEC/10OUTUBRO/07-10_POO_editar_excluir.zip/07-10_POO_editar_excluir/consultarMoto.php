<?php

include_once 'class/Moto.php';

$m = new Moto();

$m->consultar("");

?>

