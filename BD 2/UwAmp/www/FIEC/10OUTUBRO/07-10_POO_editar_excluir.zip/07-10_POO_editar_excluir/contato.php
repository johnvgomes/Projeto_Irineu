<form name="frmcadastro" id="frmcadastro"
	method="post" action="">
	<label>Nome:</label>
	<input type="text" name="txtnome" id="txtnome"
		maxlength="50" size="40">
	<br />
	
	<label>E-mail:</label>
	<input type="email" name="txtemail" id="txtemail">
	<br />
	
	<label>Telefone:</label>
	<input type="tel" name="txttel" id="txttel"
		maxlength="20" placeholder="(XX)XXXX-XXXX">
	<br />
	
	<label>Data de nascimento:</label>	
	<input type="date" name="txtidade"  id="txtidade">
	<br />
	
	<input type="submit" name="btnenviar" value="Enviar"
		id="btnenviar">
</form>
<?php

if(isset($_POST['btnenviar']) && 
	!empty($_POST['txtnome'])){
	extract($_POST,EXTR_OVERWRITE);
	
	$texto = "Nome: ".$txtnome."<br>";
	$texto .= "E-mail: ".$txtemail."<br>";
	$texto .= "Telefone: ".$txttel."<br>";
	$texto .= "Idade: ".$txtidade."<br>";
	
	echo $texto;
	
	
}
echo @date("d/m/Y");

?>






