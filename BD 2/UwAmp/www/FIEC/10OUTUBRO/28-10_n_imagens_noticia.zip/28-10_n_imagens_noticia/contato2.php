<form id="form" name="form_email" action="" method="post">
	<label>Nome:</label>
    <input type="text" name="txtnome" id="txtnome">
    <br>
    <label>E-mail:</label>
    <input type="email" name="txtemail" id="txtemail">
    <br>
    <label>Destino:</label>
    <select id="cbodestino" name="cbodestino">
    	<option value="compras@empresa.com">Compras</option>
        <option value="rh@empresa.com">Recursos Humanos</option>
        <option value="direcao@empresa.com">Direção</option>
    </select>
    <br>
    <label>Mensagem:</label>
    <textarea name="txtmsg" id="txtmsg"></textarea>
    <br>
    <input type="submit" name="btnenviar" id="btnenviar" value="Enviar">  
</form>
<?php
	if(isset($_POST['btnenviar'])){
		extract($_POST,EXTR_OVERWRITE);
		
		$mensagem = "Mensagem enviada em ".date("d/m/Y");
		$mensagem .= "<br>Nome: ".$txtnome;
		$mensagem .= "<br>E-mail: ".$txtemail;
		$mensagem .= "<br>Mensagem: ".$txtmsg;
		
		$cabecalho = "MIME-Version: 1.1\n";
		$cabecalho .= "Content-type: text/html; charset=utf-8\n";
		$cabecalho .= "From: ".$txtemail."\n";
		$cabecalho .= "Return-Path: ".$txtemail."\n";
		$cabecalho .= "Reply-To: ".$txtemail."\n";
		
		$envio = mail($cbodestino,"Assunto: Site da empresa X",
			$mensagem, $cabecalho, $txtemail);
			
		if($envio){
			echo "Mensagem enviada com sucesso. ".$txtnome.", obrigado!";
		}else{
			echo "Erro no envio";
		}
		
	}

?>
