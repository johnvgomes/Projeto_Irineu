
<?php

echo "home 123";

?>
<br>
<img src="imagem/img2.jpg">