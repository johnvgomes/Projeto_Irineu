<h3>Página Principal</h3>

<?php
echo @date("d/m/Y");
?>
