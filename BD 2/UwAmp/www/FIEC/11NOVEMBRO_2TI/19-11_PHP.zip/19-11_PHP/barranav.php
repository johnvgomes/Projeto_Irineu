<ul>
    <li><a href="?p=pagina-inicial">Página Inicial</a></li>
    <li><a href="?p=localizacao">Localização</a></li>
    <li><a href="?p=fale-conosco">Fale Conosco</a></li>
</ul>
