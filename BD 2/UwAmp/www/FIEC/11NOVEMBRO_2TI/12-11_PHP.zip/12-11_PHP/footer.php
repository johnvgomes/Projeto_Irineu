<div class="esquerda">
    <h3>FIEC I</h3>
    <p>
        Avenida Engenheiro Fábio Roberto Barnabé, 3405 <br>
        Jardim Regina - CEP: 13349-003 <br>
        Fone: (19)3801-8688 - Indaiatuba-SP
    </p>
</div>
<div class="esquerda">
    <h3>Links Úteis</h3>
</div>
<div class="direita">
    <h3>Desenvolvimento</h3>
</div>
<div class="inferior">
    &COPY; COPYRIGHT 2014 - Todos os Direitos Reservados FIEC Indaiatuba 
</div>

