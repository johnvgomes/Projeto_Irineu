<ul>
    <li><a href="#">Página Inicial</a></li>
    <li><a href="#">Localização</a></li>
    <li><a href="#">Fale Conosco</a></li>
</ul>
