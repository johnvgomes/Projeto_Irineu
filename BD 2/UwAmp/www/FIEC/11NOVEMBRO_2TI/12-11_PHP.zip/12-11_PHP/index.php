<html lang="pt-br">
    <head>
        <?php include_once 'head.php'; ?>
        <!--ALT SHIFT F-->
    </head>
    <body>
        <div class="container">
            <div class="barranav">
                <?php include_once 'barranav.php'; ?>
            </div>
            <div class="header">
                <img src="imagem/logo.png">
            </div>
            <div class="content">
                
            </div>
        </div>
        
        <div class="footer">
            <?php include_once 'footer.php'; ?>
        </div>
    </body>
</html>