<title>PHP 12/11/2014</title>
<meta charset="UTF-8">

<link href="css/estilo.css" type="text/css"
      rel="stylesheet">
<link href="css/footer.css" type="text/css"
      rel="stylesheet">
<link href="css/barranav.css" type="text/css"
      rel="stylesheet">
<link href="css/form.css" type="text/css"
      rel="stylesheet">

<meta name="description" 
      content="descrição do site">
<meta name="keywords" content="HTML,CSS,Site,JavaScript,PHP,
      Itu,Desenvolvimento,XHTML,manutenção, cartão,panfleto,corel,
      fireworks">
<meta name="author" content="Marcio Ferraz">
<link rel="shortcut icon" 
      href="imagem/icone.png">