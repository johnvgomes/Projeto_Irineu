<ul>
    <li><a href="?p=pagina-inicial">Página Inicial</a></li>
    <li><a href="?p=localizacao">Localização</a></li>
    <li><a href="?p=fale-conosco">Fale Conosco</a></li>
    <li><a href="?p=formPost">Método POST</a></li>
    <li><a href="?p=formGet">Método GET</a></li>
</ul>
