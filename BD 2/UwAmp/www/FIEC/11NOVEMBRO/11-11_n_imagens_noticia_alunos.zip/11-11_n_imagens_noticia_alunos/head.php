<meta charset="UTF-8" /> 
<title>FIEC - Indaiatuba</title>

<meta name="viewport" content="width=device-width">

<link href="<?php echo $url->getBase(); ?>css/estilo.css" rel="stylesheet" type="text/css" >
<link href="<?php echo $url->getBase(); ?>css/box.css" rel="stylesheet" type="text/css" >
<link href="<?php echo $url->getBase(); ?>css/formatacao.css" rel="stylesheet" type="text/css" >
<link href="<?php echo $url->getBase(); ?>css/templatemo_style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $url->getBase(); ?>css/jquery.ennui.contentslider.css" rel="stylesheet" type="text/css" media="screen,projection" />

<meta name="description" content="Marcio Ferraz - Desenvolvimento" />
<meta name="keywords" content="HTML,CSS,Site,JavaScript,PHP,
      Itu,Desenvolvimento,XHTML,manutenção, cartão,panfleto,corel,
      fireworks" />
<meta name="author" content="Marcio Ferraz" />
<link rel="shortcut icon" href="<?php echo $url->getBase(); ?>imagem/etec.ico" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

<script type="text/javascript">
    $(function() {
        $(window).scroll(function() {
            if ($(this).scrollTop() > 300) {
                $('.navegacao').fadeIn();
            } else {
                $('.navegacao').fadeOut();
            }
        });
    });
</script>    
<!--para carregar página-->
<script src="<?php echo $url->getBase(); ?>js/carregando.js"></script>
<script src="<?php echo $url->getBase(); ?>js/jquery.uploadify.min.js"></script>

<link rel="stylesheet" type="text/css" href="<?php echo $url->getBase(); ?>css/uploadify.css" />
<link rel="stylesheet" type="text/css" href="<?php echo $url->getBase(); ?>css/carregando.css" />

