<ul>
    <li><a href="<?php echo $url->getBase(); ?>noticias" title="Notícias" >
            <img src="<?php echo $url->getBase(); ?>imagem/icone/notes_edit.png">Notícias</a></li>

    <li><a href="<?php echo $url->getBase(); ?>contato" title="Fale Conosco">
            <img src="<?php echo $url->getBase(); ?>imagem/icone/mail.png">Contato</a> </li>

</ul>
