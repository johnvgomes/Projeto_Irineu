<div class="mapadosite1">


</div>
<div class="mapadosite1">

</div>
<div class="mapadosite2">

    
</div>

<div class="barrainferior">
    <span>&COPY; COPYRIGHT 2014 - Todos os Direitos Reservados FIEC</span>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="http://www.fiec.com.br" target="_blank" title="FIEC - Indaiatuba">
        <img src="<?php echo $url->getBase(); ?>imagem/cps.png" class="cps">
    </a>
</div>