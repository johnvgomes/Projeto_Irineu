<?php

include_once '../../class/Pagina.php';

$p = new Pagina();

$p->carregarPDF("adm");


?>
